package control;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUpload;
import org.apache.commons.fileupload.RequestContext;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.servlet.ServletRequestContext;


import util.Info;

import dao.CommDAO;

public class MainCtrl extends HttpServlet {

	public MainCtrl() {
		super();
	}

	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
	this.doPost(request, response);
	}

		public void go(String url,HttpServletRequest request, HttpServletResponse response)
		{
		try {
			request.getRequestDispatcher(url).forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		
		public void gor(String url,HttpServletRequest request, HttpServletResponse response)
		{
			try {
				response.sendRedirect(url);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		HashMap user = (HashMap)session.getAttribute("admin");
		String ac = request.getParameter("ac");
		if(ac==null)ac="";
		CommDAO dao = new CommDAO();
		String date = Info.getDateStr();
		String today = date.substring(0,10);
		String tomonth = date.substring(0,7);
		
		//登录
		if(ac.equals("login"))
		{
			    String uname = request.getParameter("uname");
			    String upass = request.getParameter("upass");
			    String utype = request.getParameter("userType");
			    String sql1="select * from sysuser where uname='"+uname+"' and upass='"+upass+"'";
			    
			    if(utype.equals("0"))
			    {
			    
			   sql1 = "select * from sysuser where uname='"+uname+"' and upass='"+upass+"' and utype='0' ";
			    }
			    if(utype.equals("1"))
			    {
			    
			     sql1 = "select * from sysuser where uname='"+uname+"' and upass='"+upass+"' and utype='1' ";
			    }
			    System.out.println(sql1);
			    	List<HashMap> list = dao.select(sql1);
			    	if(list.size()==1)
			    	{
			    	session.setAttribute("admin", list.get(0));
			    	request.setAttribute("suc", "");
			    	gor("/wuyegl/admin/main.jsp", request, response);
			    	}else{
			    		request.setAttribute("error", "");
				    	go("/admin/login.jsp", request, response);
			    	}
			    		    	
			    	
		}
		
		//修改密码
		if(ac.equals("uppass"))
		{
			    String oldpass = request.getParameter("oldpass");  
			    String upass = request.getParameter("upass");
			    if(!user.get("upass").equals(oldpass))
			    {
			    	request.setAttribute("error", "");
			    	go("/admin/uppass.jsp", request, response);
			    }else{
			    	String sql = "update sysuser set upass='"+upass+"' where id="+user.get("id");
			    	dao.commOper(sql);
			    	request.setAttribute("suc", "");
			    	go("/admin/uppass.jsp", request, response);
			    }
		}
		
		//添加房产
		if(ac.equals("addhousees"))
		{
			    String louno = request.getParameter("louno");  
			    String houseno = request.getParameter("houseno");
			    String housetype = request.getParameter("housetype");
			    String mianji = request.getParameter("mianji");
			    String bei = request.getParameter("bei");
			    String sql = "insert into housees values(null,'"+louno+"','"+houseno+"','"+housetype+"','"+mianji+"','"+bei+"')";
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	go("/admin/addhousees.jsp", request, response);
		}
		
		//修改房产
		if(ac.equals("updatehousees"))
		{
			String id = request.getParameter("id"); 
			    String louno = request.getParameter("louno");  
			    String houseno = request.getParameter("houseno");
			    String housetype = request.getParameter("housetype");
			    String mianji = request.getParameter("mianji");
			    String bei = request.getParameter("bei");
			    String sql = "update housees set louno='"+louno+"',houseno='"+houseno+"',housetype='"+housetype+"',mianji='"+mianji+"',bei='"+bei+"' where id="+id;
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	go("/admin/addhousees.jsp", request, response);
		}
		
		
		//添加员工
		if(ac.equals("addemps"))
		{
			    String truename = request.getParameter("truename");  
			    String empno = request.getParameter("empno");
			    String sex = request.getParameter("sex");
			    String gongzuo = request.getParameter("gongzuo");
			    String addr = request.getParameter("addr");
			    String sfid = request.getParameter("sfid");
			    String telphone = request.getParameter("telphone");
			    
			    String csql = "select * from emps where empno='"+empno+"'";
			    if(dao.select(csql).size()>0)
			    {
			    	request.setAttribute("error", "");
			    	go("/admin/addemps.jsp", request, response);
			    }else{
			   
			        
				    String sql = "insert into emps values(null,'"+truename+"','"+empno+"','"+sex+"','"+gongzuo+"','"+addr+"','"+sfid+"','"+telphone+"')";
				    dao.commOper(sql);
			    	request.setAttribute("suc", "");
			    	go("/admin/addemps.jsp", request, response);
			    }
			    
			    
			
		}
		
		//修改员工
		if(ac.equals("updateemps"))
		{
			String id = request.getParameter("id");
			    String truename = request.getParameter("truename");  
			    String empno = request.getParameter("empno");
			    String sex = request.getParameter("sex");
			    String gongzuo = request.getParameter("gongzuo");
			    String addr = request.getParameter("addr");
			    String sfid = request.getParameter("sfid");
			    String telphone = request.getParameter("telphone");
			    String sql = "update emps set truename='"+truename+"',empno='"+empno+"',sex='"+sex+"',gongzuo='"+gongzuo+"',addr='"+addr+"',sfid='"+sfid+"',telphone='"+telphone+"' where id="+id;
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	go("/admin/addemps.jsp", request, response);
		}
		
		
		//根据楼号得到房号
		if(ac.equals("gethouses"))
		{
			String louno = request.getParameter("louno");
			   String sql = "select * from housees where louno='"+louno+"'";
			    List<HashMap> list =  dao.select(sql);
		    	String h = "";
		    	for(HashMap m:list)
		    	{
		    		h+= m.get("houseno")+"-";
		    	}
		    	if(h.length()>0)h=h.substring(0,h.length()-1);
		    	out.print(h);
		}
		
		//用户注册
		if(ac.equals("adduser"))
		{
			    String uname = request.getParameter("uname");  
			    String upass = request.getParameter("upass");
			    String truename = request.getParameter("truename");
			    String louno = request.getParameter("louno");
			    String houseno = request.getParameter("houseno");
			    String sfid = request.getParameter("sfid");
			    String phone = request.getParameter("phone");
			    
			    String csql = "select * from sysuser where uname='"+uname+"' or (louno='"+louno+"'and houseno='"+houseno+"')";
			    if(dao.select(csql).size()>0)
			    {
			    	request.setAttribute("error", "");
			    	go("/admin/adduser.jsp", request, response);
			    }else{
			   
			    String sql = "insert into sysuser values(null,'"+uname+"','"+upass+"','"+1+"','"+truename+"','"+louno+"','"+houseno+"','"+sfid+"','"+phone+"')";
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	go("/admin/adduser.jsp", request, response);
			    }
		}
		
		//修改用户
		if(ac.equals("updateuser"))
		{
			    String id = request.getParameter("id");
			    String uname = request.getParameter("uname");  
			    String upass = request.getParameter("upass");
			    String truename = request.getParameter("truename");
			    String louno = request.getParameter("louno");
			    String houseno = request.getParameter("houseno");
			    String sfid = request.getParameter("sfid");
			    String phone = request.getParameter("phone");
			    String sql = "update sysuser set uname='"+uname+"',upass='"+upass+"',truename='"+truename+"',louno='"+louno+"',houseno='"+houseno+"',sfid='"+sfid+"',phone='"+phone+"' where id="+id;
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	request.setAttribute("id", id);
		    	go("/admin/updateuser.jsp?id="+id, request, response);
		}
		
		
		//添加设备
		if(ac.equals("addsebei"))
		{
			    String sbname = request.getParameter("sbname");
			    String sbweiz = request.getParameter("sbweiz");  
			    String bei = request.getParameter("bei");
			    String sql = "insert into sebei values(null,'"+sbname+"','"+sbweiz+"','"+bei+"')";
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	go("/admin/addsebei.jsp", request, response);
		}
		
		//修改设备
		if(ac.equals("updatesebei"))
		{
			String id = request.getParameter("id");
			    String sbname = request.getParameter("sbname");
			    String sbweiz = request.getParameter("sbweiz");  
			    String bei = request.getParameter("bei");
			    String sql = "update sebei set sbname='"+sbname+"',sbweiz='"+sbweiz+"',bei='"+bei+"' where id="+id;
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	go("/admin/addsebei.jsp", request, response);
		}
		
		//添加设备
		if(ac.equals("addsebeiwx"))
		{	String id = request.getParameter("id");
	    String sebei = request.getParameter("sebei");
	    String wxren = request.getParameter("wxren");
	    String feiyong = request.getParameter("feiyong");  
	    String wxtime = request.getParameter("wxtime"); 
			    String sql = "insert into sebeix values(null,'"+sebei+"','"+wxren+"','"+feiyong+"','"+wxtime+"')";
			    dao.commOper(sql);
		    	request.setAttribute("suc", "");
		    	go("/admin/addsebeiwx.jsp", request, response);
		}
	//修改设备维修
	if(ac.equals("updatesebeix"))
	{
		String id = request.getParameter("id");
		    String sebei = request.getParameter("sebei");
		    String wxren = request.getParameter("wxren");
		    String feiyong = request.getParameter("feiyong");  
		    String wxtime = request.getParameter("wxtime");  
		    String sql = "update sebeix set sebei='"+sebei+"',wxren='"+wxren+"',feiyong='"+feiyong+"',wxtime='"+wxtime+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addsebeiwx.jsp", request, response);
	}
	
	
	//添加停车位
	if(ac.equals("addstops"))
	{
		    String stopno = request.getParameter("stopno");
		    String weizhi = request.getParameter("weizhi");
		    String jiage = request.getParameter("jiage");  
		    String louno = request.getParameter("louno"); 
		    String houseno = request.getParameter("houseno");   
		    
		    if(houseno==null){
		    	louno="暂未";
		    	houseno="使用";
		    }
		    
		    String sql = "insert into stops values(null,'"+stopno+"','"+weizhi+"','"+jiage+"','"+louno+"','"+houseno+"')";
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addstops.jsp", request, response);
	}
	
	
	//修改停车位
	if(ac.equals("updatestops"))
	{
            String id = request.getParameter("id");
		    String stopno = request.getParameter("stopno");
		    String weizhi = request.getParameter("weizhi");
		    String jiage = request.getParameter("jiage");  
		    String louno = request.getParameter("louno"); 
		    String houseno = request.getParameter("houseno");   
		    
		    if(houseno==null){
		    	louno="暂未";
		    	houseno="使用";
		    }
		    
		    String sql = "update stops set stopno='"+stopno+"',weizhi='"+weizhi+"',jiage='"+jiage+"',louno='"+louno+"',houseno='"+houseno+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addstops.jsp", request, response);
	}
	
	
	//添加收费
	if(ac.equals("addshoufei"))
	{
	    HashMap map = (HashMap)session.getAttribute("admin");
	
	   
		
		    String uid = map.get("id").toString();
		    String nian = request.getParameter("nian");  
		    String yue = request.getParameter("yue");   
		    String je = request.getParameter("je"); 
		    String jfzt = "未审核"; 
		    String savetime = Info.getDateStr();
		   // String status = "1"; 
		    String type = request.getParameter("type"); 
		    String zh = request.getParameter("zh"); 
		    String yh = request.getParameter("yh"); 
		    String remark = request.getParameter("remark"); 
		    
		    String csql = "select * from wyf where uid='"+uid+"' and nian='"+nian+"' and type='"+type+"'";
		    System.out.println("\nbookCase*********************action="+csql);
		    if(dao.select(csql).size()>0)
		    {
		    	request.setAttribute("error", "");
		    	go("/admin/addshoufei.jsp", request, response);
		    }else{    
		    String sql = "insert into wyf values(null,'"+uid+"','"+nian+"','"+yue+"','"+je+"','"+jfzt+"','"+type+"','"+remark+"','"+zh+"','"+yh+"','"+savetime+"')";
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addshoufei.jsp", request, response);
		    }
	}
	
	
	//修改收费
	if(ac.equals("updateshoufei"))
	{
		String id = request.getParameter("id");
	
	    String nian = request.getParameter("nian");  
	    String yue = request.getParameter("yue");   

	    String je = request.getParameter("je"); 
	    String type = request.getParameter("type"); 
	   
	    String zh = request.getParameter("zh"); 
	    String yh = request.getParameter("yh"); 
	    String remark = request.getParameter("remark"); 
		    String sql = "update wyf set nian='"+nian+"',yue='"+yue+"',je='"+je+"',zh='"+zh+"',yh='"+yh+"',type='"+type+"',remark='"+remark+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addshoufei.jsp", request, response);
	}
	
	//添加仪表
	if(ac.equals("addyibiao"))
	{
		    String biaolx = request.getParameter("biaolx");
		    String weizhi = request.getParameter("weizhi");
		    String ybtime = request.getParameter("ybtime");  
		    String cbtime = request.getParameter("cbtime");  
		    String biaozhi = request.getParameter("biaozhi");  
		    String sql = "insert into yibiao values(null,'"+biaolx+"','"+weizhi+"','"+ybtime+"','"+cbtime+"','"+biaozhi+"')";
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addyibiao.jsp", request, response);
	}
	
	//修改仪表
	if(ac.equals("updateyibiao"))
	{
		    String id = request.getParameter("id");
		    String biaolx = request.getParameter("biaolx");
		    String weizhi = request.getParameter("weizhi");
		    String ybtime = request.getParameter("ybtime");  
		    String cbtime = request.getParameter("cbtime");  
		    String biaozhi = request.getParameter("biaozhi");  
		    String sql = "update yibiao set biaolx='"+biaolx+"',weizhi='"+weizhi+"',ybtime='"+ybtime+"',cbtime='"+cbtime+"',biaozhi='"+biaozhi+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addyibiao.jsp", request, response);
	}
	
	//添加投诉
	if(ac.equals("addtous"))
	{
		    String content = request.getParameter("content");
		    String sql = "insert into tous values(null,'"+content+"','"+user.get("id")+"','')";
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addmtous.jsp", request, response);
	}
	
	//修改处理意见
	if(ac.equals("updatetous"))
	{
		   String id = request.getParameter("id");
		    String content = request.getParameter("recontent");
		    String sql = "update tous set recontent='"+content+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("ersuc", "");
	    	go("/admin/addmtous.jsp", request, response);
	}
	//修改投诉
	if(ac.equals("updatetou"))
	{
		   String id = request.getParameter("id");
		    String content = request.getParameter("content");
		    String sql = "update tous set content='"+content+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addmtous.jsp", request, response);
	}
	
	//添加报修
	if(ac.equals("addbaoxiu"))
	{
		    String content = request.getParameter("content");
		    String sql = "insert into baoxiu values(null,'"+user.get("id")+"','"+content+"','')";
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addbaoxiu.jsp", request, response);
	}
	
	//添加报修处理意见
	if(ac.equals("updatebaoxiu"))
	{
		   String id = request.getParameter("id");
		    String content = request.getParameter("recontent");
		    String sql = "update baoxiu set recontent='"+content+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("ersuc", "");
	    	go("/admin/addbaoxiu.jsp", request, response);
	}
	//添加报修处理意见
	if(ac.equals("updatebaoxium"))
	{
		   String id = request.getParameter("id");
		    String content = request.getParameter("content");
		    String sql = "update baoxiu set content='"+content+"' where id="+id;
		    dao.commOper(sql);
	    	request.setAttribute("suc", "");
	    	go("/admin/addbaoxiu.jsp", request, response);
	}
	
	//报表维修
	if(ac.equals("bbsebeiwx"))
	{
		   List<HashMap> list = dao.select("select a.feiyong,a.wxren,b.sbname,a.wxtime from sebeix a,sebei b where b.id=a.sebei");
		   String[] pros = {"费用","设备","维修时间","维修人"};
		   Info.writeExcel(request.getRealPath("/upfile")+"/"+"bbsebeiwx.xls", pros, list, request, response);
	    	gor("/wuyegl/upload?filename=bbsebeiwx.xls", request, response);
	}
	
	
	//报表报修
	if(ac.equals("bbbaoxiu"))
	{
		   List<HashMap> list = dao.select("select content,recontent from baoxiu");
		   String[] pros = {"报修内容","物业方面处理意见"}; 
		   Info.writeExcel(request.getRealPath("/upfile")+"/"+"bbbaoxiu.xls", pros, list, request, response);
	    	gor("/wuyegl/upload?filename=bbbaoxiu.xls", request, response);
	}
	
	//报表投诉
	if(ac.equals("bbtous"))
	{
		   List<HashMap> list = dao.select("select content,recontent from tous ");
		   String[] pros = {"投诉内容","物业方面处理意见"}; 
		   Info.writeExcel(request.getRealPath("/upfile")+"/"+"bbtous.xls", pros, list, request, response);
	    	gor("/wuyegl/upload?filename=bbtous.xls", request, response);
	}
	
	//报表设备
	if(ac.equals("bbsebei"))
	{
		   List<HashMap> list = dao.select("select sbname,sbweiz,bei from sebei ");
		   String[] pros = {"备注","设备名称","设备位置"}; 
		   Info.writeExcel(request.getRealPath("/upfile")+"/"+"bbsebei.xls", pros, list, request, response);
	    	gor("/wuyegl/upload?filename=bbsebei.xls", request, response);
	}
	
	//报表收费
	if(ac.equals("bbshoufei"))
	{
		   List<HashMap> list = dao.select("select shoufdx,shouftime,shoufsy,bei from shoufei ");
		   String[] pros = {"收费事由","备注 ","收费对象","收费时间"}; 
		   Info.writeExcel(request.getRealPath("/upfile")+"/"+"bbshoufei.xls", pros, list, request, response);
	    	gor("/wuyegl/upload?filename=bbshoufei.xls", request, response);
	}
	
	//报表仪表
	if(ac.equals("bbyibiao"))
	{
		   List<HashMap> list = dao.select("select biaolx,weizhi,ybtime,cbtime,biaozhi from yibiao  ");
		   String[] pros = {"仪表类型","仪表位置","仪表时间","查表时间","仪表值 "}; 
		   Info.writeExcel(request.getRealPath("/upfile")+"/"+"bbyibiao.xls", pros, list, request, response);
	    	gor("/wuyegl/upload?filename=bbyibiao.xls", request, response);
	}
	
	
	//添加网上缴费
	if(ac.equals("addjf"))
	{
		String frombanks = request.getParameter("frombanks");
		String tobanks = request.getParameter("tobanks");
		String author = user.get("id").toString();
		String jftype = request.getParameter("jftype");
		String feiyong = request.getParameter("feiyong");
		String fromacc = request.getParameter("fromacc");
		String toacc = request.getParameter("toacc");
	    String sql = "insert into wsjf values(null,'"+frombanks+"','"+tobanks+"','"+author+"','"+jftype+"','"+feiyong+"','"+fromacc+"','"+toacc+"')";
	    dao.commOper(sql);
    	request.setAttribute("suc", "");
    	go("/admin/addjf.jsp", request, response);
	}
	
	//修改网上缴费
	if(ac.equals("updatejf"))
	{
		String id = request.getParameter("id");
		String frombanks = request.getParameter("frombanks");
		String tobanks = request.getParameter("tobanks");
		String author = user.get("id").toString();
		String jftype = request.getParameter("jftype");
		String feiyong = request.getParameter("feiyong");
		String fromacc = request.getParameter("fromacc");
		String toacc = request.getParameter("toacc");
	    String sql = "update wsjf set frombanks='"+frombanks+"',tobanks='"+tobanks+"',author='"+author+"',jftype='"+jftype+"',feiyong='"+feiyong+"',fromacc='"+fromacc+"',toacc='"+toacc+"' where id="+id;
	    dao.commOper(sql);
    	request.setAttribute("suc", "");
    	go("/admin/addjf.jsp", request, response);
	}
	
	dao.close();
	out.flush();
	out.close();
}


	public void init() throws ServletException {
		// Put your code here
	}
	
	

}
