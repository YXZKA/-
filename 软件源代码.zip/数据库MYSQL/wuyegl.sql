/*
MySQL Data Transfer
Source Host: localhost
Source Database: wuyegl
Target Host: localhost
Target Database: wuyegl
Date: 2017/11/26 11:12:15
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for baoxiu
-- ----------------------------
CREATE TABLE `baoxiu` (
  `id` int(11) NOT NULL auto_increment,
  `author` varchar(255) default NULL,
  `content` varchar(255) default NULL,
  `recontent` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for emps
-- ----------------------------
CREATE TABLE `emps` (
  `id` int(11) NOT NULL auto_increment,
  `truename` varchar(255) default NULL,
  `empno` varchar(255) default NULL,
  `sex` varchar(255) default NULL,
  `gongzuo` varchar(255) default NULL,
  `addr` varchar(255) default NULL,
  `sfid` varchar(255) default NULL,
  `telphone` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for housees
-- ----------------------------
CREATE TABLE `housees` (
  `id` int(11) NOT NULL auto_increment,
  `louno` varchar(255) default NULL,
  `houseno` varchar(255) default NULL,
  `housetype` varchar(255) default NULL,
  `mianji` varchar(255) default NULL,
  `bei` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sebei
-- ----------------------------
CREATE TABLE `sebei` (
  `id` int(11) NOT NULL auto_increment,
  `sbname` varchar(255) default NULL,
  `sbweiz` varchar(255) default NULL,
  `bei` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sebeix
-- ----------------------------
CREATE TABLE `sebeix` (
  `id` int(11) NOT NULL auto_increment,
  `sebei` varchar(255) default NULL,
  `wxren` varchar(255) default NULL,
  `feiyong` varchar(255) default NULL,
  `wxtime` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for shoufei
-- ----------------------------
CREATE TABLE `shoufei` (
  `id` int(11) NOT NULL auto_increment,
  `shoufdx` varchar(50) default NULL,
  `shouftime` varchar(50) default NULL,
  `shoufsy` varchar(50) default NULL,
  `bei` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for stops
-- ----------------------------
CREATE TABLE `stops` (
  `id` int(11) NOT NULL auto_increment,
  `stopno` varchar(255) default NULL,
  `weizhi` varchar(255) default NULL,
  `jiage` varchar(255) default NULL,
  `louno` varchar(255) default NULL,
  `houseno` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for sysuser
-- ----------------------------
CREATE TABLE `sysuser` (
  `id` int(11) NOT NULL auto_increment,
  `uname` varchar(255) default NULL,
  `upass` varchar(255) default NULL,
  `utype` varchar(255) default NULL,
  `truename` varchar(255) default NULL,
  `louno` varchar(255) default NULL,
  `houseno` varchar(255) default NULL,
  `phone` varchar(255) default NULL,
  `sfid` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for tous
-- ----------------------------
CREATE TABLE `tous` (
  `id` int(11) NOT NULL auto_increment,
  `content` varchar(255) default NULL,
  `author` varchar(255) default NULL,
  `recontent` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for wsjf
-- ----------------------------
CREATE TABLE `wsjf` (
  `id` int(11) NOT NULL auto_increment,
  `frombanks` varchar(150) default NULL,
  `tobanks` varchar(150) default NULL,
  `author` varchar(255) default NULL,
  `jftype` varchar(255) default NULL,
  `feiyong` varchar(255) default NULL,
  `fromacc` varchar(255) default NULL,
  `toacc` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for wyf
-- ----------------------------
CREATE TABLE `wyf` (
  `id` int(11) NOT NULL auto_increment,
  `uid` varchar(50) default NULL,
  `nian` varchar(50) default NULL,
  `yue` varchar(50) default NULL,
  `je` varchar(50) default NULL,
  `status` varchar(50) default NULL,
  `type` varchar(50) default NULL,
  `remark` text,
  `zh` varchar(50) default NULL,
  `yh` varchar(50) default NULL,
  `savetime` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for wyfset
-- ----------------------------
CREATE TABLE `wyfset` (
  `id` int(11) NOT NULL auto_increment,
  `dj` varchar(50) default NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for yibiao
-- ----------------------------
CREATE TABLE `yibiao` (
  `id` int(11) NOT NULL auto_increment,
  `biaolx` varchar(255) default NULL,
  `weizhi` varchar(255) default NULL,
  `ybtime` varchar(255) default NULL,
  `cbtime` varchar(255) default NULL,
  `biaozhi` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `baoxiu` VALUES ('2', '5', '222', '222');
INSERT INTO `emps` VALUES ('2', '小胡', 'no.34321', '女', '扫地', '武汉市汉口青年路33333号', '42108719887654218x', '139909098672');
INSERT INTO `housees` VALUES ('4', '1A', '1A101', '三室一厅', '128', '');
INSERT INTO `housees` VALUES ('5', '1B', '1B101', '二室一厅', '89', '');
INSERT INTO `housees` VALUES ('6', '1A', '1A102', '一室一厅', '45', '');
INSERT INTO `housees` VALUES ('7', '1B', '1B102', '四室二厅', '200', '');
INSERT INTO `sebei` VALUES ('3', '抽水机', '1A102地下室', '1A102地下室');
INSERT INTO `sebeix` VALUES ('2', '2', '水电维修公司的小张', '1021元', '2017年3月1日');
INSERT INTO `sebeix` VALUES ('4', '3', '22', '22', '2017-11-17');
INSERT INTO `shoufei` VALUES ('6', 'zhangsan', '2017-11-7', '水电费', '111');
INSERT INTO `stops` VALUES ('2', 'CW001', 'CW001-101', '100', '1A', '1A101');
INSERT INTO `sysuser` VALUES ('1', 'admin', '123', '0', '小胡', null, null, null, null);
INSERT INTO `sysuser` VALUES ('5', 'zhangsan', '123', '1', '张三', '1A', '1A101', '130210125410211211', '13888888888');
INSERT INTO `sysuser` VALUES ('6', 'lisi', '123', '1', '李四', '1A', '1A102', '130212415421414412', '13777777777');
INSERT INTO `tous` VALUES ('6', '8888888888', '5', '333');
INSERT INTO `wsjf` VALUES ('1', '中信银行123', '工商银行', '3', '10年的物业费', '2000', '321232433254452234', '432341132335345346');
INSERT INTO `wsjf` VALUES ('2', '222', '22', '5', '22', '222', '22', '222');
INSERT INTO `wyf` VALUES ('9', '5', '2017-07', 'null', '3', '已审核', '电费', '33', '33', '33', '2017-11-25 11:38:19');
INSERT INTO `yibiao` VALUES ('1', '电表', '1A101', '2017-11-01-2017-11-30', '2017-11-10', '300');
